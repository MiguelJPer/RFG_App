package com.example.rfg_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}